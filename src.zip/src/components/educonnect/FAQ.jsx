import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import Reveal from './Reveal';
import SectionHeading from './SectionHeading';

const FAQS = [
  {
    q: 'What is EduConnect?',
    a: 'EduConnect is an AI-powered platform that connects students with learning support tailored to their subjects, goals, learning preferences, availability and needs. It helps students find tutors who genuinely fit how they learn.',
  },
  {
    q: 'How does tutor matching work?',
    a: 'Students build a profile describing their learning needs. EduConnect then surfaces tutors whose expertise, teaching style, availability and other factors align with that profile — so matches are relevant, not random.',
  },
  {
    q: 'Who is EduConnect for?',
    a: 'Students looking for personalised learning support, tutors who want to reach the right students, and institutions or organisations — schools, NGOs, community programmes — extending learning support to their communities.',
  },
  {
    q: 'Is EduConnect only for Mauritius?',
    a: 'EduConnect is being developed first for Mauritius, with the local education ecosystem in mind. The technology is designed so it can eventually serve learners in other regions too.',
  },
  {
    q: 'How do I join as a tutor?',
    a: 'You can express your interest through the Get Started link below. As the platform grows, we onboard tutors whose expertise and teaching approach match the needs of students on EduConnect.',
  },
  {
    q: 'Is EduConnect free to use?',
    a: 'EduConnect is in an early stage. Details about pricing and access will be shared as the platform develops — you can join our community to stay informed.',
  },
];

function FaqItem({ item, open, onToggle }) {
  return (
    <div className="border-b border-border/60 last:border-0">
      <button
        onClick={onToggle}
        className="flex w-full items-center justify-between gap-4 py-5 text-left group"
        aria-expanded={open}
      >
        <span className={cn('font-display text-base sm:text-lg font-semibold transition-colors', open ? 'text-accent' : 'text-primary group-hover:text-accent')}>
          {item.q}
        </span>
        <span className={cn('flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-border/60 text-muted-foreground transition-all', open && 'bg-accent/10 border-accent/30 text-accent rotate-180')}>
          <ChevronDown className="h-4 w-4" />
        </span>
      </button>
      <div className={cn('grid transition-all duration-300 ease-out', open ? 'grid-rows-[1fr] opacity-100 pb-5' : 'grid-rows-[0fr] opacity-0')}>
        <div className="overflow-hidden">
          <p className="text-sm sm:text-base text-muted-foreground leading-relaxed pr-12">{item.a}</p>
        </div>
      </div>
    </div>
  );
}

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section className="py-20 lg:py-28 bg-secondary/30">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="Questions"
            title="Frequently asked questions."
            subtitle="Everything you might want to know about EduConnect — and if it's not here, reach out."
          />
        </Reveal>

        <Reveal delay={0.1}>
          <div className="mt-12 rounded-2xl border border-border/60 bg-card px-6 sm:px-8 shadow-float">
            {FAQS.map((item, i) => (
              <FaqItem
                key={item.q}
                item={item}
                open={openIndex === i}
                onToggle={() => setOpenIndex(openIndex === i ? -1 : i)}
              />
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}