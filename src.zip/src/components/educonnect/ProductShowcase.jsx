import React from 'react';
import Reveal from './Reveal';
import SectionHeading from './SectionHeading';
import StudentProfileMockup from './mockups/StudentProfileMockup';
import TutorMatchingMockup from './mockups/TutorMatchingMockup';
import TutorProfileMockup from './mockups/TutorProfileMockup';
import CourseMaterialsMockup from './mockups/CourseMaterialsMockup';

const SHOWCASES = [
  {
    n: '01',
    tag: 'Student Experience',
    title: 'Start with what makes you unique.',
    body: 'Students build a profile around their subjects, goals, preferences and learning needs — creating the foundation for a more relevant learning experience.',
    Mockup: StudentProfileMockup,
    reverse: false,
  },
  {
    n: '02',
    tag: 'Tutor Matching',
    title: 'From requirements to relevant matches.',
    body: 'EduConnect helps students explore learning support based on the information that matters to their learning journey — subject, skill, schedule, language and style.',
    Mockup: TutorMatchingMockup,
    reverse: true,
  },
  {
    n: '03',
    tag: 'Tutor Discovery',
    title: 'More than a name and a subject.',
    body: 'Understand how a tutor teaches before deciding who fits your learning needs — expertise, teaching philosophy, availability and more.',
    Mockup: TutorProfileMockup,
    reverse: false,
  },
  {
    n: '04',
    tag: 'Learning & Platform',
    title: 'Everything you need to keep learning moving.',
    body: 'Access structured course materials — documents, videos and presentations — organised into sections, with offline support for learning on your schedule.',
    Mockup: CourseMaterialsMockup,
    reverse: true,
  },
];

export default function ProductShowcase() {
  return (
    <section className="py-20 lg:py-28 bg-secondary/30">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal>
          <SectionHeading
            eyebrow="The product"
            title="See EduConnect in action."
            subtitle="A closer look at how EduConnect connects students with learning support that fits their needs."
          />
        </Reveal>

        <div className="mt-16 lg:mt-20 space-y-20 lg:space-y-28">
          {SHOWCASES.map((s) => {
            const Mockup = s.Mockup;
            return (
              <div key={s.n} className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
                <Reveal className={s.reverse ? 'lg:order-2' : ''}>
                  <div className="max-w-md mx-auto lg:mx-0">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="font-display text-sm font-bold text-accent">{s.n}</span>
                      <span className="h-px w-8 bg-accent/40" />
                      <span className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">{s.tag}</span>
                    </div>
                    <h3 className="font-display text-2xl sm:text-3xl font-bold text-primary tracking-tight text-balance leading-[1.15]">
                      {s.title}
                    </h3>
                    <p className="mt-4 text-base text-muted-foreground leading-relaxed">{s.body}</p>
                  </div>
                </Reveal>

                <Reveal delay={0.15} className={s.reverse ? 'lg:order-1' : ''}>
                  <div className="relative">
                    <div className="absolute -inset-4 bg-gradient-to-br from-brand-sky/30 via-brand-lavender/20 to-transparent rounded-3xl blur-2xl opacity-60 -z-10" />
                    <Mockup />
                  </div>
                </Reveal>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}